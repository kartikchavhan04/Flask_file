from flask import Flask
from flask_sqlalchemy import SQLAlchemy


db = SQLAlchemy()

def create_app():
    app = Flask(__name__)

    app.config['SECRET_KEY'] = 'your-secret-key'
    app.config['SQLAlchemy_DATABASE_URI'] = 'sqllite:///todo.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    db.__init__(app)

    from app.routes.auth import auth_db
    from app.routes.auth import tasks_db

    app.register_blueprint(auth_db)
    app.register_blueprint(tasks_db)

    return app

