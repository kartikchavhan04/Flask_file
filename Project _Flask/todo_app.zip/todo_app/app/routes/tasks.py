from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from app import db
from app.models import Task
from functools import wraps
from datetime import datetime

# Create Tasks Blueprint
tasks_db = Blueprint('tasks', __name__)


# ==================== DECORATOR ====================
def login_required(f):
    """Decorator to check if user is logged in"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in first.', 'warning')
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated_function


# ==================== TASK ROUTES ====================
@tasks_db.route('/tasks', methods=['GET'])
@login_required
def task_list():
    """Display all tasks for logged-in user"""
    user_id = session.get('user_id')
    
    try:
        tasks = Task.query.filter_by(user_id=user_id).all()
        total_tasks = len(tasks)
        completed_tasks = len([t for t in tasks if t.status == 'completed'])
        pending_tasks = total_tasks - completed_tasks
        
        return render_template('tasks.html', 
                             tasks=tasks, 
                             total_tasks=total_tasks,
                             completed_tasks=completed_tasks,
                             pending_tasks=pending_tasks,
                             username=session.get('username'))
    except Exception as e:
        flash('Error loading tasks.', 'error')
        return redirect(url_for('tasks.task_list'))


@tasks_db.route('/task/add', methods=['GET', 'POST'])
@login_required
def add_task():
    """Add a new task"""
    if request.method == 'POST':
        user_id = session.get('user_id')
        title = request.form.get('title')
        description = request.form.get('description', '')
        
        # Validation
        if not title or len(title.strip()) == 0:
            flash('Task title is required.', 'error')
            return redirect(url_for('tasks.task_list'))
        
        if len(title) > 100:
            flash('Task title must be less than 100 characters.', 'error')
            return redirect(url_for('tasks.task_list'))
        
        try:
            new_task = Task(
                user_id=user_id,
                title=title.strip(),
                description=description.strip(),
                status='pending',
                created_at=datetime.utcnow()
            )
            db.session.add(new_task)
            db.session.commit()
            flash('Task added successfully!', 'success')
            return redirect(url_for('tasks.task_list'))
        except Exception as e:
            db.session.rollback()
            flash('Error adding task. Please try again.', 'error')
            return redirect(url_for('tasks.task_list'))
    
    return render_template('add_task.html')


@tasks_db.route('/task/<int:task_id>/update', methods=['POST'])
@login_required
def update_task(task_id):
    """Update a task status"""
    user_id = session.get('user_id')
    
    try:
        task = Task.query.filter_by(id=task_id, user_id=user_id).first()
        
        if not task:
            flash('Task not found.', 'error')
            return redirect(url_for('tasks.task_list'))
        
        status = request.form.get('status')
        title = request.form.get('title')
        description = request.form.get('description', '')
        
        # Validation
        if status and status not in ['pending', 'in_progress', 'completed']:
            flash('Invalid status.', 'error')
            return redirect(url_for('tasks.task_list'))
        
        if title and len(title.strip()) == 0:
            flash('Task title cannot be empty.', 'error')
            return redirect(url_for('tasks.task_list'))
        
        if title:
            task.title = title.strip()
        if status:
            task.status = status
        if description is not None:
            task.description = description.strip()
        
        task.updated_at = datetime.utcnow()
        db.session.commit()
        flash('Task updated successfully!', 'success')
        return redirect(url_for('tasks.task_list'))
    except Exception as e:
        db.session.rollback()
        flash('Error updating task.', 'error')
        return redirect(url_for('tasks.task_list'))


@tasks_db.route('/task/<int:task_id>/delete', methods=['POST'])
@login_required
def delete_task(task_id):
    """Delete a task"""
    user_id = session.get('user_id')
    
    try:
        task = Task.query.filter_by(id=task_id, user_id=user_id).first()
        
        if not task:
            flash('Task not found.', 'error')
            return redirect(url_for('tasks.task_list'))
        
        db.session.delete(task)
        db.session.commit()
        flash('Task deleted successfully!', 'success')
        return redirect(url_for('tasks.task_list'))
    except Exception as e:
        db.session.rollback()
        flash('Error deleting task.', 'error')
        return redirect(url_for('tasks.task_list'))


@tasks_db.route('/task/<int:task_id>/toggle', methods=['POST'])
@login_required
def toggle_task_status(task_id):
    """Toggle task status between pending and completed"""
    user_id = session.get('user_id')
    
    try:
        task = Task.query.filter_by(id=task_id, user_id=user_id).first()
        
        if not task:
            return jsonify({'success': False, 'message': 'Task not found'}), 404
        
        # Toggle status
        task.status = 'completed' if task.status == 'pending' else 'pending'
        task.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'success': True, 
            'message': 'Task status updated',
            'new_status': task.status
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': 'Error updating task'}), 500


@tasks_db.route('/task/<int:task_id>', methods=['GET'])
@login_required
def task_detail(task_id):
    """View task details"""
    user_id = session.get('user_id')
    
    try:
        task = Task.query.filter_by(id=task_id, user_id=user_id).first()
        
        if not task:
            flash('Task not found.', 'error')
            return redirect(url_for('tasks.task_list'))
        
        return render_template('task_detail.html', task=task, username=session.get('username'))
    except Exception as e:
        flash('Error loading task.', 'error')
        return redirect(url_for('tasks.task_list'))


@tasks_db.route('/tasks/search', methods=['GET'])
@login_required
def search_tasks():
    """Search tasks by title or description"""
    user_id = session.get('user_id')
    query = request.args.get('q', '').strip()
    
    if not query:
        return redirect(url_for('tasks.task_list'))
    
    try:
        tasks = Task.query.filter_by(user_id=user_id).filter(
            (Task.title.ilike(f'%{query}%')) | (Task.description.ilike(f'%{query}%'))
        ).all()
        
        return render_template('tasks.html', 
                             tasks=tasks, 
                             search_query=query,
                             username=session.get('username'))
    except Exception as e:
        flash('Error searching tasks.', 'error')
        return redirect(url_for('tasks.task_list'))


@tasks_db.route('/tasks/filter/<status>', methods=['GET'])
@login_required
def filter_tasks(status):
    """Filter tasks by status"""
    user_id = session.get('user_id')
    
    if status not in ['pending', 'in_progress', 'completed']:
        flash('Invalid status filter.', 'error')
        return redirect(url_for('tasks.task_list'))
    
    try:
        tasks = Task.query.filter_by(user_id=user_id, status=status).all()
        
        return render_template('tasks.html', 
                             tasks=tasks, 
                             filter_status=status,
                             username=session.get('username'))
    except Exception as e:
        flash('Error filtering tasks.', 'error')
        return redirect(url_for('tasks.task_list'))
